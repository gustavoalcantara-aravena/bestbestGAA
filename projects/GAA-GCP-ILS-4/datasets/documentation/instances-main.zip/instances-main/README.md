# DIMACS Graph Instances

This repo contains the DIMACS graph instances in ASCII graph
format, along with source for the `binfmt` translator
software for converting between ASCII and binary graph
formats and the format [specification](./ccformat.pdf) in
PDF.

This is essentially a cleaned-up copy of
<https://mat.tepper.cmu.edu/COLOR/instances.html>.
